<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Role;
use App\Models\Permission;
use App\Models\ModelHasRole;
use App\Models\RoleHasPermission;

class RoleController extends Controller
{
    public function index(Request $request){
        $model_has_role = ModelHasRole::all();

        $role = Role::all();
        $user = User::all();
        $permission = Permission::all();
        return view('admin.role.index', [
            'roles' => $role,
            'users' => $user,
            'model_has_role' => $model_has_role
        ]);
    }

    public function addRoleUser(){
        $model_has_role = ModelHasRole::all();
        $roles = Role::all();
        $users = User::all();
        $permission = Permission::all();

        return view('admin.role.add_role', [
            'roles' => $roles,
            'users' => $users,
            'model_has_role' => $model_has_role
        ]);
    }

    public function saveAddRoleUser(Request $request){
        // dd($request->user_id);
        // foreach ($request->user_id as $key => $value) {
        //     echo $value;
        // }
        $request->validate(
            [
                'role_id' => 'required',
                'user_id' => 'required'
            ],
            [
                'role_id.required' => "Hãy chọn role!",
                'user_id.required' => "Hãy chọn user!"
            ]
        );
        $role_id = $request->role_id;
        $user = User::where('id', $request->user_id)->first();
        dd($user);
        // $user->assignRole($request->role_id);
        // return redirect(route('role.index'))->with('success', "ok");
    }

    public function addRolePermission(){
        $model_has_role = ModelHasRole::all();
        $roles = Role::all();
        $permissions = Permission::all();
        $role_has_permission = RoleHasPermission::all();
        // dd($role_has_permission);
        return view('admin.role.add_role_permission', [
            'roles' => $roles,
            'permissions' => $permissions,
            'model_has_role' => $model_has_role,
            'role_has_permission' => $role_has_permission
        ]);
    }

    public function saveAddRolePermission(){
        //
    }
}