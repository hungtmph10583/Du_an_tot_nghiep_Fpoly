<?php $__env->startSection('title', 'Tài khoản'); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('pageStyle'); ?>
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/customer.css')); ?>">
<?php $__env->stopSection(); ?>
	<!-- content -->
<div class="section-mt"></div>
<section class="custommer">
    <div class="customer-container">
        <div class="title">
            <h1>Thông tin cá nhân</h1>
            <span>Cập nhật các thông tin cá nhân cơ bản giúp cho việc liên lạc và trải nghiệm dễ dàng hơn</span>
        </div>
        <div class="information-customer">
            <form action="" method="POST" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
                <div class="avatar-customer">
                    <img src="<?php echo e(asset( 'storage/' . $model->avatar)); ?>" id="blah" alt="User profile picture">
                    <div class="foot-avatar" id="cc">
                        <label for="hidden-avatar">Đổi avatar</label>
                        <input hidden type="file" name="uploadfile" id="hidden-avatar">
                    </div>
                    <?php $__errorArgs = ['uploadfile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="group">
                    <label for="">Họ tên <span class="text-red">*</span></label>
                    <input type="text" name="name" placeholder="Họ và tên" value="<?php echo e(Auth::user()->name); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="group">
                    <label for="">Email <span class="text-red">*</span></label>
                    <input type="text" name="email" placeholder="Emai" value="<?php echo e(Auth::user()->email); ?>">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="group">
                    <label for="">Số điện thoại <span class="text-red">*</span></label>
                    <input type="text" name="phone" placeholder="Số điện thoại" value="<?php echo e(Auth::user()->phone); ?>">
                </div>
                <div class="group-last">
                    <a href="<?php echo e(route('client.customer.info')); ?>">Hủy bỏ</a>
                    <button type="submit">Cập nhật</button>
                </div>
            </form>
        </div>
    </div>
</section>
	<!-- content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagejs'); ?>
<script>
    var a = '';
        function readURL(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
					// $('#cc').append(`
					// 	<img class="add-product-preview-img" id="blah" src="#" alt="your image" />
					// `);
					document.getElementById("cc").style.display = 'block';
				reader.onload = function(e) {
					$('#blah').attr('src', e.target.result);
				}
				reader.readAsDataURL(input.files[0]);
				}
			}
			$("#hidden-avatar").change(function() {
				readURL(this);
		});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/client/customer/updateinfo.blade.php ENDPATH**/ ?>