<?php $__env->startSection('title', 'Thông tin tài khoản'); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="card card-secondary my-0">
			<div class="card-header">
				<ol class="breadcrumb float-sm-left ">
					<li class="breadcrumb-item">
						<a class="card-title" href="<?php echo e(route('user.index')); ?>">Danh sách tài khoản</a>
					</li>
					<li class="breadcrumb-item active">Profile</li>
				</ol>
			</div>
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-3">
				<!-- Profile Image -->
				<div class="card card-success card-outline">
					<div class="card-body box-profile">
						<div class="text-center">
							<img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset( 'storage/' . $user->avatar)); ?>" alt="User profile picture">
						</div>

						<h3 class="profile-username text-center"><?php echo e($user->name); ?></h3>

						<?php $__currentLoopData = $mdh_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mdhr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($mdhr->model_id === $user->id): ?>
							<p class="text-muted text-center">
								<?php echo e(ucfirst($mdhr->role->name)); ?>

							</p>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<ul class="list-group list-group-unbordered mb-3">
							<li class="list-group-item">
								<b>Vai trò</b>
								<?php $__currentLoopData = $mdh_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mdhr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($mdhr->model_id === $user->id): ?>
									<b class="float-right <?php echo e(($mdhr->role_id === 1 ? 'text-danger' : ($mdhr->role_id === 2 ? 'text-success' : 'text-info'))); ?>">
									<?php echo e(ucfirst($mdhr->role->name)); ?>

									</b>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</li>
							<li class="list-group-item">
								<b>Trạng thái</b>
								<span class="btn <?php echo e($user->status == 1 ? 'btn-success' : 'btn-warning'); ?> float-right btn-sm text-light">
									<?php echo e($user->status == 1 ? 'Active' : 'Inactive'); ?>

								</span>
							</li>
							<li class="list-group-item">
								<b>
									<i class="fa fa-mobile" aria-hidden="true"></i> Phone
								</b>
								<b class="float-right">
									<?php if($user->phone != ''): ?>
										<?php echo e($user->phone); ?>

									<?php else: ?>
										null
									<?php endif; ?>
								</b>
							</li>
						</ul>
						<?php if(auth()->check() && auth()->user()->hasAnyRole('admin|manage')): ?>
							<a href=" 
								<?php if($user->id === 1): ?>
									<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
										<?php echo e(route('user.edit', ['id' => $user->id])); ?>

									<?php else: ?>
										#
									<?php endif; ?>
								<?php else: ?>
									<?php echo e(route('user.edit', ['id' => $user->id])); ?>

								<?php endif; ?>
								" class="btn btn-success btn-block"
								<?php if(Auth::user()->id === $user->id): ?>
									<?php echo e(route('user.edit', ['id' => $user->id])); ?>

								<?php elseif(Auth::user()->id > 1 && $user->id == 1): ?>
									onclick="alert('Bạn éo có tủi mà đòi sửa thông tin của mình nhóe :))')"
								<?php else: ?>

								<?php endif; ?>
								><b>Sửa tài khoản</b></a>
						<?php else: ?>
							<?php if(Auth::user()->id === $user->id): ?>
							<a href="<?php echo e(route('user.edit', ['id' => $user->id])); ?>" class="btn btn-success btn-block"><b>Sửa tài khoản</b></a>
							<?php endif; ?>
						<?php endif; ?>
					</div>
					<!-- /.card-body -->
				</div>
				<!-- /.card -->
			</div>
			<!-- /.col -->
			<div class="col-md-9">
				<div class="card card-success card-outline">
					<div class="card-header">
						<h5>Personal information</h5>
					</div>
					<div class="card-body">
						<strong><i class="fab fa-facebook-square"></i> Facebook</strong>

						<p class="text-muted">
						
						</p>

						<hr>

						<strong><i class="fab fa-instagram-square"></i> Instagram</strong>

						<p class="text-muted">
							
						</p>

						<hr>

						<strong><i class="fas fa-envelope"></i> Email</strong>

						<p class="text-muted">
							<?php echo e($user->email); ?>

						</p>
					</div>
				</div>
				<!-- /.card -->
			</div>
			<!-- /.col -->
		</div>
		<!-- /.row -->
	</div><!-- /.container-fluid -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/admin/user/pro-file.blade.php ENDPATH**/ ?>