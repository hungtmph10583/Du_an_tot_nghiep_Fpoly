<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Css -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('client-theme/images/logo.png')); ?>">
    <?php echo $__env->make('layouts.client.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('pageStyle'); ?>
</head>

<body>
    <!-- Header - Start -->
    <?php echo $__env->make('layouts.client.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Header - End -->

    <!-- Content Start -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- Content End -->

    <!-- 
      * scroll to top 
      * start
    -->
    <button id="scrollToTop" class="scrollToTop">
        <i class="fas fa-chevron-up"></i>
    </button>
    <!-- 
      * scroll to top 
      * end
    -->

    <!-- Footer - Start -->
    <?php echo $__env->make('layouts.client.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer - End -->
    <!-- JS -->
    <?php echo $__env->make('layouts.client.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('pagejs'); ?>
    <!-- end JS -->
</body>

</html><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/layouts/client/main.blade.php ENDPATH**/ ?>