<?php $__env->startSection('title', 'Danh sách tài khoản'); ?>

<?php $__env->startSection('content'); ?>
	<!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="card card-secondary my-0">
                <div class="card-header">
                    <ol class="breadcrumb float-sm-left ">
                        <li class="breadcrumb-item card-title">Danh sách tài khoản</li>
                    </ol>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid pb-1">
            <div class="card card-success card-outline">
				<div class="card-header">
					<form action="" method="get">
                        <div class="row">
							<div class="col-9">

                            </div>
                            <div class="col-3">
								<div class="input-group input-group-sm">
									<input class="form-control" type="text" name="keyword" <?php if(isset($searchData['keyword'])): ?> value="<?php echo e($searchData['keyword']); ?>" <?php endif; ?> placeholder="Search">
									<div class="input-group-append">
										<button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
									</div>
								</div>
                            </div>
                        </div>
                    </form>
				</div>
                <div class="card-body">
                    <div class="row">
                        <table class="table table-striped">
                            <thead>
                                <th>STT</th>
                                <th>Name</th>
                                <th>
                                    <?php if(auth()->check() && auth()->user()->hasAnyRole('admin|manage')): ?>
                                        <a href="<?php echo e(route('user.add')); ?>" class="btn btn-outline-info float-right">Thêm tài khoản</a>
                                    <?php else: ?>
                                        <a href="#" onclick="alert('Bạn không được cấp quyền để tạo tài khoản?')" class="btn-outline-info float-right">Thêm tài khoản</a>
                                    <?php endif; ?>
                                </th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e((($users->currentPage()-1)*5) + $loop->iteration); ?></td>
                                    <td><?php echo e($u->name); ?></td>
                                    <td>
                                        <span class="float-right">
                                            <a href="<?php echo e(route('user.profile', ['id' => $u->id])); ?>" class="btn btn-outline-info"><i class="far fa-eye"></i></a>
                                            <a href="<?php echo e(route('user.edit', ['id' => $u->id])); ?>" class="btn btn-outline-success"><i class="far fa-edit"></i></a>
                                            <a href="<?php echo e(route('user.remove', ['id' => $u->id])); ?>" class="btn btn-outline-danger" onclick="return confirm('Bạn có chắc muốn xóa tài khoản này?')"><i class="far fa-trash-alt"></i></a>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="d-flex justify-content-end">
                            <?php echo e($users->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /.container-fluid -->
	</section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/admin/user/index.blade.php ENDPATH**/ ?>