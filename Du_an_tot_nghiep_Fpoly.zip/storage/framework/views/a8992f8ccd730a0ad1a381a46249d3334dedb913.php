<!-- link slide -->
<link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
<!-- custom css file link -->
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/slide.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/header.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/product.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/productDetail.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/blog.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/media.css')); ?>">
<!-- font awesome cdn link -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/layouts/client/style.blade.php ENDPATH**/ ?>