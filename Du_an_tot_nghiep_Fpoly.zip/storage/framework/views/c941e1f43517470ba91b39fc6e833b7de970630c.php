<?php $__env->startSection('title', 'Sản phẩm yêu thích'); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('pageStyle'); ?>
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/account-info.css')); ?>">
<?php $__env->stopSection(); ?>
	<!-- content -->
<div class="section-mt"></div>
<section class="account-info">
    <div class="account-info-container">
        <div class="account-info-left">
            <div class="information">
                <div class="avatar">
                    <img src="<?php echo e(asset( 'storage/' . Auth::user()->avatar)); ?>" alt="User profile picture">
                </div>
                <span class="name"><?php echo e(Auth::user()->name); ?></span>
            </div>
            <ul>
                <li>
                    <a href="<?php echo e(route('client.customer.info')); ?>" class="active">
                        <i class="fas fa-user"></i>
                        Thông tin tài khoản
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('client.customer.orderHistory')); ?>">
                        <i class="fas fa-swatchbook"></i>
                        Quản lý đơn hàng
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('client.customer.favoriteProduct')); ?>">
                        <i class="fas fa-heart"></i>
                        Sản phẩm yêu thích
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('client.customer.review')); ?>">
                        <i class="fas fa-star-half-alt"></i>
                        Nhận xét của tôi
                    </a>
                </li>
            </ul>
        </div>
        <div class="account-info-right">
            <div class="title">Sản phẩm yêu thich</div>
            <div class="group">
                <img src="<?php echo e(asset('client-theme/images/error.jpg')); ?>" alt="error">
            </div>
        </div>
    </div>
</section>
	<!-- content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/client/customer/favorite-product.blade.php ENDPATH**/ ?>