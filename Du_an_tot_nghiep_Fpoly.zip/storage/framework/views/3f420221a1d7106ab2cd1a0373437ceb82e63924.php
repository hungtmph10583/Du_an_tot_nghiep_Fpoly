<?php $__env->startSection('title', 'Sửa tài khoản'); ?>

<?php $__env->startSection('content'); ?>
	<!-- BEGIN: Subheader -->
	<div class="content-header">
		<div class="container-fluid">
			<div class="card card-secondary my-0">
				<div class="card-header">
					<ol class="breadcrumb float-sm-left ">
                        <li class="breadcrumb-item">
							<a class="card-title" href="<?php echo e(route('user.index')); ?>">Danh sách tài khoản</a>
						</li>
                        <li class="breadcrumb-item active">Sửa tài khoản</li>
                    </ol>
				</div>
			</div><!-- /.row -->
		</div><!-- /.container-fluid -->
	</div>
	<!-- END: Subheader -->
	<!-- Main content -->
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-3">
					<!-- Profile Image -->
					<div class="card card-success card-outline">
						<div class="card-body box-profile">
							<div class="text-center" id="cc">
								<img class="profile-user-img img-fluid img-circle" id="blah" src="<?php echo e(asset( 'storage/' . $model->avatar)); ?>" alt="User profile picture">
							</div>

							<h3 class="profile-username text-center"><?php echo e($model->name); ?></h3>
							<?php $__currentLoopData = $mdh_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mdhr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($mdhr->model_id === $model->id): ?>
								<p class="text-muted text-center">
									<?php echo e(ucfirst($mdhr->role->name)); ?>

								</p>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							<ul class="list-group list-group-unbordered mb-3">
								<li class="list-group-item">
									<b>Vai trò</b>
									<?php $__currentLoopData = $mdh_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mdhr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($mdhr->model_id === $model->id): ?>
										<b class="float-right <?php echo e(($mdhr->role_id === 1 ? 'text-danger' : ($mdhr->role_id === 2 ? 'text-success' : 'text-info'))); ?>">
											<?php echo e(ucfirst($mdhr->role->name)); ?>

										</b>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</li>
								<li class="list-group-item">
									<b>Trạng thái</b>
									<i class="<?php echo e($model->status == 1 ? 'fa fa-check text-success' : 'fas fa-user-lock text-danger'); ?> float-right pr-3"></i>
								</li>
								<li class="list-group-item">
									<b>
										<i class="fa fa-mobile" aria-hidden="true"></i> Phone
									</b>
									<p class="float-right"><?php echo e($model->phone); ?></p>
								</li>
							</ul>
						</div>
						<!-- /.card-body -->
					</div>
					<!-- /.card -->
				</div>
				<!-- /.col -->
				<div class="col-md-9">
					<div class="card card-success card-outline">
						<div class="card-header">
							<h5>Personal information</h5>
						</div>
						<div class="card-body">
							<?php if(session('msg') != null): ?>
								<b class="text-left text-danger"><?php echo e(session('msg')); ?></b>
							<?php endif; ?>
							<form action="" method="POST" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>
							<div class="row">
								<div class="col-6">
									<div class="form-group">
										<label for="">Name</label>
										<input type="text" name="name" class="form-control" value="<?php echo e($model->name); ?>" placeholder="Tên tài khoản">
										<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="text-danger"><?php echo e($message); ?></span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
									<div class="form-group">
										<label for="">Email</label>
										<input type="text" name="email" class="form-control" value="<?php echo e($model->email); ?>" placeholder="Nhập vào email">
										<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="text-danger"><?php echo e($message); ?></span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
									<div class="form-group">
										<label for="">Số điện thoại</label>
										<input type="text" name="phone" class="form-control" value="<?php echo e($model->phone); ?>" placeholder="Nhập vào số điện thoại">
										<?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="text-danger"><?php echo e($message); ?></span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   
									</div>
									<div class="form-group">
										<label for="">Ảnh đại diện</label>
										<input type="file" name="uploadfile" id="imgInp" class="form-control">
										<?php $__errorArgs = ['uploadfile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="text-danger"><?php echo e($message); ?></span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
								<div class="col-6">
									<?php if(auth()->check() && auth()->user()->hasAnyRole('admin|manage')): ?>
									<div class="form-group">
                                        <label for="">Trạng thái</label>
                                        <div class="form-control">
                                            <label class="pr-1">
                                                <input type="radio" name="status" value="1" <?php if($model->status == 1): ?> checked <?php endif; ?>> Hiển thị
                                            </label>
                                            <label class="pl-1">
                                                <input type="radio" name="status" value="0" <?php if($model->status == 0): ?> checked <?php endif; ?>> Ẩn
                                            </label>
                                        </div>
                                    </div>
									<?php endif; ?>

									<?php if($model->id != 1): ?>
										<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
										<div class="form-group">
											<label for="">Vai trò</label>
											<div class="form-control">
											<?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<label class="pr-1">
													<input type="radio" name="role_id" value="<?php echo e($r->id); ?>"	
													<?php $__currentLoopData = $mdh_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mdh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<?php if($model->id == $mdh->model_id): ?>
															<?php if($r->id == $mdh->role_id): ?>
															checked
															<?php endif; ?>
														<?php endif; ?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													> <?php echo e($r->name); ?>

												</label>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</div>
										</div>
										<?php endif; ?>
									<?php endif; ?>
								</div>
								<div class="text-right pl-2">
										<button type="submit" class="btn btn-success">Lưu</button>
									<a href="<?php echo e(route('user.index')); ?>" class="btn btn-danger">Hủy</a>
								</div>
							</div>
						</form>
						</div>
					</div>
					<!-- /.card -->
				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
		</div><!-- /.container-fluid -->
	</section>
	<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagejs'); ?>
    <script>
		var a = '';
        function readURL(input) {

			if (input.files && input.files[0]) {
				var reader = new FileReader();
					// $('#cc').append(`
					// 	<img class="add-product-preview-img" id="blah" src="#" alt="your image" />
					// `);
					document.getElementById("cc").style.display = 'block';
				

				reader.onload = function(e) {
					$('#blah').attr('src', e.target.result);
				}
				reader.readAsDataURL(input.files[0]);
				}
			}

			$("#imgInp").change(function() {
				readURL(this);
			
		});
		
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/admin/user/edit-form.blade.php ENDPATH**/ ?>