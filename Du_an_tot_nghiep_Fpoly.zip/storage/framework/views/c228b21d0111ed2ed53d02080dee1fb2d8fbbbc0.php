 <?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
        <div class="card card-secondary my-0">
            <div class="card-header">
                <ol class="breadcrumb float-sm-left ">
                    <li class="breadcrumb-item"><a class="card-title" href="<?php echo e(route('order.index')); ?>">Thay đổi trạng thái Đơn hàng</a></li>
                    <li class="breadcrumb-item active">Sửa Đơn hàng</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <form action="" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card">
            <div class="card-header">
                Chi tiết đơn hàng
            </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-6"></div>
                        <div class="col-3">
                            <div class="form-group">
                                <label for="">Trạng thái thanh toán</label>
                                <select name="payment_status" id="" class="form-control">
                                    <option value="1" <?php if($order->payment_status == 1): ?> selected <?php endif; ?>>Chưa thanh toán</option>
                                    <option value="2" <?php if($order->payment_status == 2): ?> selected <?php endif; ?>>Đã thanh toán</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <label for="">Trạng thái đơn hàng</label>
                                <select name="delivery_status" id="" class="form-control">
                                    <option value="1" <?php if($order->delivery_status == 1): ?> selected <?php endif; ?>>Đang chờ xử lý</option>
                                    <option value="2" <?php if($order->delivery_status == 2): ?> selected <?php endif; ?>>Đang giao hàng</option>
                                    <option value="3" <?php if($order->delivery_status == 3): ?> selected <?php endif; ?>>Giao hàng thành công</option>
                                    <option value="0" <?php if($order->delivery_status == 0): ?> selected <?php endif; ?>>Hủy đơn hàng</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <div>
                                    <b>Khách hàng: </b>
                                    <b><?php echo e($order->name); ?></b>
                                </div>
                                <div>
                                    <b>Email: </b>
                                    <span><?php echo e($order->email); ?></span>
                                </div>
                                <div>
                                    <b>Số điện thoại: </b>
                                    <span><?php echo e($order->phone); ?></span>
                                </div>
                                <div>
                                    <b>Địa chỉ giao hàng: </b>
                                    <span><?php echo e($order->shipping_address); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col"></div>
                                    <div class="col">Mã đơn hàng</div>
                                    <div class="col"><?php echo e($order->code); ?></div>
                                </div>
                                <div class="row">
                                    <div class="col"></div>
                                    <div class="col">Trạng thái thanh toán</div>
                                    <div class="col">
                                        <span class="btn 
                                            <?php if($order->payment_status == 1): ?>
                                                btn-danger
                                            <?php elseif($order->payment_status == 2): ?>
                                                btn-success
                                            <?php else: ?>
                                                btn-danger
                                            <?php endif; ?>
                                        btn-sm text-light">
                                            <?php if($order->payment_status == 1): ?>
                                                Chưa thanh toán
                                            <?php elseif($order->payment_status == 2): ?>
                                                Đã thanh toán
                                            <?php else: ?>
                                                Lỗi code
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col"></div>
                                    <div class="col">Ngày đặt hàng</div>
                                    <div class="col"><?php echo e($order->created_at->format('d/m/Y')); ?></div>
                                </div>
                                <div class="row">
                                    <div class="col"></div>
                                    <div class="col">Tổng cộng</div>
                                    <div class="col"><?php echo e(number_format($order->grand_total,0,',','.')); ?>đ</div>
                                </div>
                                <div class="row">
                                    <div class="col"></div>
                                    <div class="col">Phương thức thanh toán</div>
                                    <div class="col">Thanh toán khi nhận hàng</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col" class="text-center">Ảnh</th>
                                    <th scope="col">Mô tả</th>
                                    <th scope="col">Hình thức giao hàng</th>
                                    <th scope="col">Số lượng</th>
                                    <th scope="col">Giá bán</th>
                                    <th scope="col">Thành tiền</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row">1</th>
                                    <td class="text-center"><img src="<?php echo e(asset( 'storage/' . $value->product->image)); ?>" alt="" width="70"></td>
                                    <td><?php echo e($value->product->name); ?></td>
                                    <td>Giao hàng tận nhà</td>
                                    <td><?php echo e($value->quantity); ?></td>
                                    <td>
                                        <?php
                                            $tinh = $value->price/$value->quantity;
                                            echo number_format($tinh,0,',','.');
                                        ?> / sản phẩm
                                    </td>
                                    <td><?php echo e(number_format($value->price,0,',','.')); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-9"></div>
                        <div class="col-3">
                            <div class="form-group">
                                <div class="row border-bottom mt-1 mb-1">
                                    <div class="col form-group">Tổng phụ</div>
                                    <div class="col form-group">
                                        <?php
                                            $total = $value->order->grand_total - $value->tax;
                                            echo number_format($total,0,',','.') . 'đ';
                                        ?>
                                    </div>
                                </div>
                                <div class="row border-bottom mt-1 mb-1">
                                    <div class="col form-group">Thuế</div>
                                    <div class="col form-group"><?php echo e(number_format($value->tax,0,',','.')); ?>đ</div>
                                </div>
                                <div class="row border-bottom mt-1 mb-1">
                                    <div class="col form-group">Giao hàng</div>
                                    <div class="col form-group">Free</div>
                                </div>
                                <div class="row border-bottom mt-1 mb-1">
                                    <div class="col form-group"><b>Tổng tiền</b></div>
                                    <div class="col form-group"><b><?php echo e(number_format($value->order->grand_total,0,',','.')); ?>đ</b></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6"></div>
                        <div class="col-6 text-right"><br>
                            <div class="form-group">
                                <input type="checkbox" name="send_mail" id="send_mail" value="send_mail">
                                <label class="form-check-label" for="send_mail">Gửi email cập nhật cho khách hàng</label>
                            </div>
                            <button type="submit" class="btn btn-info">Lưu</button>
                            <a href="<?php echo e(route('order.index')); ?>" class="btn btn-danger">Hủy</a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <br>
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/admin/order/edit-form.blade.php ENDPATH**/ ?>