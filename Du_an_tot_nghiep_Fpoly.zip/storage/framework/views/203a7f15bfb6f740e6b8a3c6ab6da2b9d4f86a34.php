<?php $__env->startSection('title', 'Giỏ hàng'); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('pageStyle'); ?>
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/blog.css')); ?>">
<?php $__env->stopSection(); ?>
	<!-- content -->
<div class="section-mt"></div>
<!-- <section class="search">
    <div class="container">
        <form action="" class="search-form">
            <div class="form-field">
                <input type="search" class="form-input" id="search-box" placeholder=" ">
                <label for="search" class="form-label"><i class="fas fa-search"></i> search here...</label>
            </div>
        </form>
    </div>
</section> -->
<!-- section product -->
<section class="blogs">
    <div class="blog-container">
        <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="blog-item">
            <div class="item-top">
                <div class="thumbnail">
                    <a href="<?php echo e(route('client.blog.detail', ['id' => $value->id])); ?>">
                    <img src="<?php echo e(asset( 'storage/' . $value->image)); ?>" alt="Bài viết này hiện chưa có ảnh hoặc ảnh bị lỗi hiển thị!">
                    </a>
                </div>
            </div>
            <div class="item-bottom">
                <div class="item-extra">
                    <ul>
                        <li>
                            <i class="fas fa-user"></i>
                            <span>Tác giả: </span>
                            <span class="author"><?php echo e($value->user->name); ?></span>
                        </li>
                        <li class="middle">
                            <i class="far fa-calendar-alt"></i>
                            <span>
                                <?php echo e(date_format($value->created_at,"d/m/Y H:i:s")); ?>

                            </span>
                        </li>
                        <li>
                            <i class="far fa-comments"></i>
                            <span class="comment">1</span>
                            <span>Bình luận</span>
                        </li>
                    </ul>
                </div>
                <h1 class="title"><?php echo e($value->title); ?></h1>
                <a href="<?php echo e(route('client.blog.detail', ['id' => $value->id])); ?>" class="btn">Chi tiết</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="paging">
    <?php echo e($blog->links('vendor.pagination.custom')); ?>

    </div>
</section>
<!-- scroll to top -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/client/blog/index.blade.php ENDPATH**/ ?>