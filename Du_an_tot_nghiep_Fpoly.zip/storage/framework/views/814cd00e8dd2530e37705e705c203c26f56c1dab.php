<?php $__env->startSection('title', 'Lịch sử mua hàng'); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('pageStyle'); ?>
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/account-info.css')); ?>">
<?php $__env->stopSection(); ?>
	<!-- content -->
<div class="section-mt"></div>
<section class="account-info">
    <div class="account-info-container">
        <div class="account-info-left">
            <div class="information">
                <div class="avatar">
                    <img src="<?php echo e(asset( 'storage/' . Auth::user()->avatar)); ?>" alt="User profile picture">
                </div>
                <span class="name"><?php echo e(Auth::user()->name); ?></span>
            </div>
            <ul>
                <li>
                    <a href="<?php echo e(route('client.customer.info')); ?>">
                        <i class="fas fa-user"></i>
                        Thông tin tài khoản
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('client.customer.orderHistory')); ?>" class="active">
                        <i class="fas fa-swatchbook"></i>
                        Quản lý đơn hàng
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('client.customer.favoriteProduct')); ?>">
                        <i class="fas fa-heart"></i>
                        Sản phẩm yêu thích
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('client.customer.review')); ?>">
                        <i class="fas fa-star-half-alt"></i>
                        Nhận xét của tôi
                    </a>
                </li>
            </ul>
        </div>
        <div class="account-info-right">
            <div class="title">Đơn hàng của tôi</div>
            <table class="greenTable">
                <thead>
                    <tr>
                        <th>Mã đơn hàng</th>
                        <th>Sản phẩm</th>
                        <th>Ngày mua</th>
                        <th>Tổng tiền</th>
                        <th>Trạng thái đơn hàng</th>
                    </tr>
                </thead>
                <tbody class="list-overflow">
                    <?php $__currentLoopData = $orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $or): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($or->id == $orD->order_id): ?>
                            <tr>
                                <td><?php echo e($orD->order->code); ?></td>
                                <td>
                                    <a href="<?php echo e(route('client.product.detail', ['id' => $orD->product->id])); ?>">
                                        <img src="<?php echo e(asset( 'storage/' . $orD->product->image)); ?>" alt="Sản phẩm này hiện chưa có ảnh hoặc ảnh bị lỗi hiển thị!" width="100">
                                    </a>
                                </td>
                                <td><?php echo e($orD->order->created_at->diffForHumans()); ?></td>
                                <td><?php echo e(number_format($orD->order->grand_total,0,',','.')); ?>đ</td>
                                <td>
                                    <?php if($orD->order->delivery_status == 1): ?>
                                        Đang chờ xử lý
                                    <?php elseif($orD->order->delivery_status == 2): ?>
                                        Đang giao hàng
                                    <?php elseif($orD->order->delivery_status == 3): ?>
                                        Giao hàng thành công
                                    <?php elseif($orD->order->delivery_status == 0): ?>
                                        Hủy đơn hàng
                                    <?php else: ?>
                                        Lỗi code
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
	<!-- content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/client/customer/order-history.blade.php ENDPATH**/ ?>