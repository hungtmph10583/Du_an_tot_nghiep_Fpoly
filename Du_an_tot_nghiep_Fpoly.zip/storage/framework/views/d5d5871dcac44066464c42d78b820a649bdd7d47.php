<?php $__env->startSection('title', 'Sản phẩm'); ?>

<?php $__env->startSection('content'); ?>
	<!-- content -->
<div class="section-mt"></div>
<section class="search">
    <div class="container">
        <form action="" class="search-form">
            <div class="form-field">
                <input type="search" class="form-input" id="search-box" placeholder=" ">
                <label for="search" class="form-label"><i class="fas fa-search"></i> search here...</label>
            </div>
            <!-- <button for="search-box">
                <i class="fas fa-search"></i>
            </button> -->
        </form>
    </div>
</section>
<!-- section product -->
<section class="products">
    <div class="product-top">
        <form action="">
            <div class="double">
                <div class="form-item">
                    <label for="">Danh mục</label>
                    <select name="" id="">
                        <option value="">Tìm kiếm theo danh mục</option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cate->id); ?>"><?php echo e($cate->name); ?>t</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-item">
                    <label for="">Sắp xếp theo</label>
                    <select name="" id="">
                        <option value="">Giá cao nhất</option>
                        <option value="">Giá thấp nhất</option>
                        <option value="">Bán chạy nhất</option>
                        <option value="">Hàng mới</option>
                    </select>
                </div>
            </div>
            <div class="clear-both"></div>
            <button>Search</button>
            <div class="clear-both"></div>
        </form>
    </div>
    <div class="product-container">
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product-item">
            <div class="item-top">
                <div class="product-lable">
                </div>
                <div class="product-thumbnail">
                    <a href="<?php echo e(route('client.product.detail', ['id' => $p->slug])); ?>">
                        <img src="<?php echo e(asset( 'storage/' . $p->image)); ?>" alt="Sản phẩm này hiện chưa có ảnh hoặc ảnh bị lỗi hiển thị!">
                    </a>
                </div>
                <div class="product-extra">
                    <form action="<?php echo e(route('buyNow')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id_hidden" value="<?php echo e($p->id); ?>">
                        <input type="hidden" name="discount_price" value="<?php echo e($p->discount); ?>">
                        <input type="hidden" name="quantity" value="1">
                        <button type="submit" class="btn-buyNow">Mua hàng</button>
                    </form>
                </div>
            </div>
            <div class="item-bottom">
                <div class="product-info">
                    <a href="<?php echo e(route('client.product.detail', ['id' => $p->id])); ?>" class="name"><?php echo e($p->name); ?></a>
                    <?php if($p->discount == ''): ?>
                        <span class="price"><?php echo e(number_format($p->price)); ?>đ</span>
                    <?php else: ?>
                        <span class="discount"><?php echo e(number_format($p->price)); ?>đ</span><br>
                        <span class="price">
                            <?php
                                echo number_format($p->price - $p->discount).'đ';
                            ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="paging">
    <?php echo e($product->links('vendor.pagination.custom')); ?>

    </div>
</section>
	<!-- content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/client/product/index.blade.php ENDPATH**/ ?>