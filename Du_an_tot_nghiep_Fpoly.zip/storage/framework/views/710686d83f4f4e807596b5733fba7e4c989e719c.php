<header class="header-wrapper">
    <div class="header-top-bar">
        <div class="container">
            <div class="row">
                <ul class="header-item-left">
                    <li>
                        <a href="mailto:<?php echo e($generalSetting->email); ?>">
                            <i class="fas fa-envelope"></i>
                            <span><?php echo e($generalSetting->email); ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fas fa-phone-alt"></i>
                            <span><?php echo e($generalSetting->phone); ?></span>
                        </a>
                    </li>
                </ul>
                <div class="header-item none"></div>
                <ul class="header-item">
                    <?php if(Auth::check()): ?>
                    <?php if(auth()->check() && auth()->user()->hasAnyRole('admin|manage')): ?>
                    <li>
                        <a href="<?php echo e(route('dashboard.index')); ?>">
                        <i class="fas fa-cogs"></i>
                            <span>Đăng nhập quản trị</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li>
                        <a href="<?php echo e(route('client.customer.info')); ?>">
                            <i class="fas fa-user"></i>
                            <span><?php echo e(Auth::user()->name); ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('logout')); ?>">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                    <?php else: ?>
                    <li>
                        <a href="<?php echo e(route('login')); ?>">
                            <i class="fas fa-user"></i>
                            <span>Tài khoản</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('login')); ?>">
                            <i class="fas fa-sign-in-alt"></i>
                            <span>Login</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="header-middle-bar">
        <div class="container">
            <div class="row">
                <div class="header-item icon-bars">
                    <div class="fas fa-bars" id="menu-btn"></div>
                </div>
                <div class="header-item none"></div>
                <div class="header-item">
                    <a href="<?php echo e(route('client.home')); ?>" class="logo">
                        <!-- <i class="fas fa-paw"></i> <b> LOLI<span>PET</span></b> -->
                        <img src="<?php echo e(asset('client-theme/images/logo_full.png')); ?>" alt="">
                    </a>
                </div>
                <div class="header-item">
                    <nav class="navbar">
                        <ul class="nav-item">
                            <li>
                                <a href="<?php echo e(route('client.home')); ?>">Trang chủ</a>
                            </li>
                            <li>
                                <a href="./introduce.html">Giới thiệu</a>
                            </li>
                            <li>
                                <a href="./index.html">Danh mục</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('client.product.index')); ?>">Sản phẩm</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('client.blog.index')); ?>">Tin tức</a>
                            </li>
                            <li>
                                <a href="./contact.html">Liên hệ</a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="header-item icons">
                    <!-- <div class="cart">
                        <i class="fas fa-heart"></i>
                    </div> -->
                    <div class="cart">
                        <a href="<?php echo e(route('client.cart.index')); ?>">
                            <i class="fas fa-shopping-cart"></i>
                            <span class="title">Giỏ hàng</span>
                            <span class="btn-number">
                                <?php
                                    $count = Cart::content()->count();
                                ?>
                                    <?php echo e($count); ?>

                            </span>
                        </a>
                    </div>
                </div>
                <!--  -->
                <!-- <div class="shopping-cart">
                    <div class="box">
                        <i class="fas fa-trash-alt"></i>
                        <img src="<?php echo e(asset('client-theme/images/002.jpg')); ?>" alt="">
                        <div class="content">
                            <h3>pit bull</h3>
                            <span class="price">12.500 VND</span> <br>
                            <span class="quantity">số lượng : 2</span>
                        </div>
                    </div>
                    <div class="box">
                        <i class="fas fa-trash-alt"></i>
                        <img src="<?php echo e(asset('client-theme/images/003.jpg')); ?>" alt="">
                        <div class="content">
                            <h3>supper dog pit bull</h3>
                            <span class="price">12.500 VND</span> <br>
                            <span class="quantity">số lượng : 2</span>
                        </div>
                    </div>
                    <div class="box">
                        <i class="fas fa-trash-alt"></i>
                        <img src="<?php echo e(asset('client-theme/images/004.jpg')); ?>" alt="">
                        <div class="content">
                            <h3>pit bull</h3>
                            <span class="price">12.500 VND</span> <br>
                            <span class="quantity">số lượng : 2</span>
                        </div>
                    </div>
                    <div class="total">tổng cộng : 24.000 VND</div>
                    <a href="#" class="btn">xem giỏ hàng</a>
                    <a href="#" class="btn">thanh toán</a>
                </div> -->
            </div>
        </div>
    </div>
</header>
<!-- <?php if(session('msg') != null): ?>
<div class="msg-alert">
    <p class="text-alert">
        <span><?php echo e(session('msg')); ?></span>
        <i class="fas fa-times" data-dismiss="alert"></i>
    </p>
</div>
<?php endif; ?> -->
<?php if(session()->has('message')): ?>
    <div class="msg-alert <?php if(session()->has('message')): ?> active <?php endif; ?>">
        <p class="text-alert">
            <span><?php echo e(session()->get('message')); ?></span>
            <i class="fas fa-times"></i>
        </p>
    </div>
<?php endif; ?>
<?php $__env->startSection('pagejs'); ?>
<script>
        $(".msg-alert i").click(function() {
            $(".msg-alert").removeClass('active');
        });
</script>
<?php $__env->stopSection(); ?><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/layouts/client/header.blade.php ENDPATH**/ ?>