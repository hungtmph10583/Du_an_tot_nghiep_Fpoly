
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
        <div class="card card-light my-0">
            <div class="card-header">
                <ol class="breadcrumb float-sm-left ">
                    <li class="breadcrumb-item"><a class="card-title" href="<?php echo e(route('slide.index')); ?>">Danh sách Slide</a></li>
                    <li class="breadcrumb-item active">Thêm slide</li>
                </ol>
            </div>
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
    <div class="container-fluid pb-1">
        <form action="" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <img class="img-custom-edit" src="<?php echo e(asset( 'storage/' . $slide->image)); ?>" alt="slide này hiện chưa có ảnh hoặc ảnh bị lỗi hiển thị!">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="">Ảnh slide</label>
                                <input type="file" name="uploadfile" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="">Trạng thái</label>
                                <select name="status" class="form-control">
                                    <option value="1" <?php if($slide->status == 1): ?> selected <?php endif; ?>>Hiển thị</option>
                                    <option value="0" <?php if($slide->status == 0): ?> selected <?php endif; ?>>Không</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-info ml-2">Lưu</button>
                                <a href="<?php echo e(route('slide.index')); ?>" class="btn btn-danger">Hủy</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div><!-- /.container-fluid -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/admin/slide/edit-form.blade.php ENDPATH**/ ?>