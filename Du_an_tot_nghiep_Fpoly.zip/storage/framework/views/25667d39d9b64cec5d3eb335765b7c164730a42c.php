
<?php $__env->startSection('content'); ?>

    <div class="content-header">
        <div class="container-fluid">
            <div class="card card-secondary my-0">
                <div class="card-header">
                    <ol class="breadcrumb float-sm-left ">
                        <li class="breadcrumb-item card-title">Danh sách đơn hàng</li>
                    </ol>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid pb-1">
            <div class="card">
                <div class="card-body table-responsive pad">
                    <?php if(session('success') != null || session('danger') != null): ?>
                    <div class="alert <?php if(session('success')): ?> alert-success <?php else: ?> alert-danger <?php endif; ?> alert-dismissible fade show" role="alert">
                        <strong><?php if(session('success')): ?> Success <?php else: ?> Danger <?php endif; ?></strong> <?php echo e(session('success')); ?> <?php echo e(session('danger')); ?>.
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <!--  -->
                    <div class="alert <?php if(session('success')): ?> alert-success <?php else: ?> alert-danger <?php endif; ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h5>
                                <i class="icon fas fa-check"></i> Success!
                                <i class="icon fas fa-exclamation-triangle"></i> Danger!
                        </h5>
                        <?php echo e(session('success')); ?> <?php echo e(session('danger')); ?>.
                    </div>
                    <?php endif; ?>
                    <form action="" method="get">
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="">Search</label>
                                    <input class="form-control" placeholder="Search" type="text" name="keyword" <?php if(isset($searchData['keyword'])): ?> value="<?php echo e($searchData['keyword']); ?>" <?php endif; ?>>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="">Sắp xếp theo</label>
                                    <select class="form-control" name="order_by" >
                                        <option value="">Mặc định</option>
                                        <option value="1">Đơn đang chờ xử lý</option>
                                        <option value="2">Đơn đang giao hàng</option>
                                        <option value="3">Đơn giao thành công</option>
                                        <option value="0">Đơn hàng đã huỷ</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col">
                                <br>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-info mt-2">Tìm kiếm</button>
                                </div>
                            </div>
                        </div>
                    </form>
                    <div class="row">
                        <table class="table table-striped">
                            <thead>
                                <th>STT</th>
                                <th>Mã đơn hàng</th>
                                <th>Khách hàng</th>
                                <th>Thời gian</th>
                                <!-- <th>Tổng tiền</th> -->
                                <th>Trạng thái</th>
                                <th class="text-center">Thanh toán</th>
                                <th><span class="float-right mr-4">Lựa chọn</span></th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e((($order->currentPage()-1)*7) + $loop->iteration); ?></td>
                                    <td><?php echo e($value->code); ?></td>
                                    <td><?php echo e($value->name); ?></td>
                                    <td><?php echo e($value->created_at->format('d/m/Y')); ?></td>
                                    <!-- <td><?php echo e(number_format($value->grand_total,0,',','.')); ?><span>đ</span></td> -->
                                    <td>
                                        <span class="btn btn-sm 
                                            <?php if($value->delivery_status == 1): ?>
                                                btn-secondary
                                            <?php elseif($value->delivery_status == 2): ?>
                                                btn-warning
                                            <?php elseif($value->delivery_status == 3): ?>
                                                btn-success
                                            <?php elseif($value->delivery_status == 0): ?>
                                                btn-danger
                                            <?php else: ?>
                                                btn-danger
                                            <?php endif; ?>
                                        text-light">
                                            <?php if($value->delivery_status == 1): ?>
                                                Đang chờ xử lý
                                            <?php elseif($value->delivery_status == 2): ?>
                                                Đang giao hàng
                                            <?php elseif($value->delivery_status == 3): ?>
                                                Giao hàng thành công
                                            <?php elseif($value->delivery_status == 0): ?>
                                                Hủy đơn hàng
                                            <?php else: ?>
                                                Lỗi code
                                            <?php endif; ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <i class="<?php echo e($value->payment_status == 1 ? 'far fa-times-circle text-danger' : 'far fa-check-circle text-success'); ?>"></i>
                                    </td>
                                    <td>
                                        <span class="float-right">
                                            <a href="#" class="btn btn-outline-info"><i class="far fa-eye"></i></a>
                                            <a href="<?php echo e(route('order.edit', ['id' => $value->id])); ?>" class="btn btn-outline-success"><i class="far fa-edit"></i></a>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="d-flex justify-content-end">
                            <?php echo e($order->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/admin/order/index.blade.php ENDPATH**/ ?>