<?php $__env->startSection('title', 'Đánh giá của tôi'); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('pageStyle'); ?>
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/account-info.css')); ?>">
<?php $__env->stopSection(); ?>
	<!-- content -->
<div class="section-mt"></div>
<section class="account-info">
    <div class="account-info-container">
        <div class="account-info-left">
            <div class="information">
                <div class="avatar">
                    <img src="<?php echo e(asset( 'storage/' . Auth::user()->avatar)); ?>" alt="User profile picture">
                </div>
                <span class="name"><?php echo e(Auth::user()->name); ?></span>
            </div>
            <ul>
                <li>
                    <a href="<?php echo e(route('client.customer.info')); ?>">
                        <i class="fas fa-user"></i>
                        Thông tin tài khoản
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('client.customer.orderHistory')); ?>">
                        <i class="fas fa-swatchbook"></i>
                        Quản lý đơn hàng
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('client.customer.favoriteProduct')); ?>">
                        <i class="fas fa-heart"></i>
                        Sản phẩm yêu thích
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('client.customer.review')); ?>" class="active">
                        <i class="fas fa-star-half-alt"></i>
                        Nhận xét của tôi
                    </a>
                </li>
            </ul>
        </div>
        <div class="account-info-right">
            <div class="title">Đánh giá sản phẩm</div>
            <table class="greenTable">
                <thead>
                    <tr>
                        <th>Sản phẩm</th>
                        <th>Xếp hạng sp</th>
                        <th>Nội dung đánh giá</th>
                        <th>Thời gian</th>
                        <td>Hành động</td>
                    </tr>
                </thead>
                <tbody class="list-overflow">
                    <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($rv->product_id == $pro->id): ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('client.product.detail', ['id' => $rv->product->id])); ?>">
                                        <img src="<?php echo e(asset( 'storage/' . $rv->product->image)); ?>" alt="Sản phẩm này hiện chưa có ảnh hoặc ảnh bị lỗi hiển thị!" width="100">
                                    </a>
                                </td>
                                <td>
                                    <span class="star">
                                       <?php for($count=1; $count<=5; $count++): ?>
                                            <?php if($count <= $pro->reviews->rating): ?>
                                                <i class="fas fa-star rating"></i>
                                            <?php else: ?>
                                                <i class="far fa-star"></i>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </span>
                                </td>
                                <td class="comment"><?php echo e($rv->comment); ?></td>
                                <td><?php echo e($rv->created_at->diffForHumans()); ?></td>
                                <td>
                                    <a href="#" class="edit-review">
                                        <i class="far fa-edit"></i>
                                    </a>
                                    <a href="<?php echo e(route('deleteReview', ['id' => $rv->id])); ?>" onclick="return confirm('Bạn có chắc muốn xóa review này?')" class="delete-review">
                                        <i class="far fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
	<!-- content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/client/customer/review.blade.php ENDPATH**/ ?>