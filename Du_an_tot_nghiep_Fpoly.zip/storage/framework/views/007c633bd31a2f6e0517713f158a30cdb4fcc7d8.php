<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>
<!-- custom JS file link -->
<script src="<?php echo e(asset('client-theme/js/script.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('client-theme/js/main.js')); ?>"></script> -->
<!-- <script src="<?php echo e(asset('client-theme/js/cart.js')); ?>"></script> -->
<script src="https://code.jquery.com/jquery-latest.js"></script><?php /**PATH F:\Du_an_tot_nghiep_Fpoly\resources\views/layouts/client/script.blade.php ENDPATH**/ ?>